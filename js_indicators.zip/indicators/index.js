const elder = require('./elder');
const rsi = require('./rsi');
const sma = require('./sma');

module.exports = {
    elder,
    rsi,
    sma,
};
